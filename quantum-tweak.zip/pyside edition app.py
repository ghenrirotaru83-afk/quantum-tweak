﻿
import math, platform, subprocess, sys, time
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor, QFont, QPainter, QPen
from PySide6.QtWidgets import *

try:
    import psutil; HAS_PSUTIL=True
except Exception:
    HAS_PSUTIL=False

BG0,BG1,BG2,BG3,BG4="#07060e","#05040b","#0c0b18","#111025","#080715"
PUR,PUR2,PUR3="#7c3aed","#a78bfa","#6d28d9"
GRN,RED="#22c55e","#ef4444"
BORDER,T1,T2,T3,T4="#131125","#eceaff","#706a90","#38345a","#221f3a"

def card():
    w=QFrame(); w.setStyleSheet(f"background:{BG2};border:1px solid {BORDER};border-radius:10px;"); return w

class NavItem(QFrame):
    def __init__(self, icon, text, active=False, cb=None):
        super().__init__(); self.a=active; self.cb=cb; self.setCursor(Qt.PointingHandCursor)
        l=QHBoxLayout(self); l.setContentsMargins(10,7,10,7)
        self.i=QLabel(icon); self.i.setFont(QFont("Segoe UI Emoji",11)); self.i.setFixedWidth(24)
        self.t=QLabel(text); self.t.setFont(QFont("Segoe UI",10)); l.addWidget(self.i); l.addWidget(self.t,1); self.refresh()
    def mousePressEvent(self,e):
        if self.cb: self.cb()
    def set_active(self,v): self.a=v; self.refresh()
    def enterEvent(self,e):
        if not self.a: self.setStyleSheet("background:#1c1a2a;border-radius:8px;")
    def leaveEvent(self,e):
        if not self.a: self.refresh()
    def refresh(self):
        if self.a:
            self.setStyleSheet("background:#1f1c30;border-radius:8px;"); self.i.setStyleSheet(f"color:{PUR2};"); self.t.setStyleSheet(f"color:{T1};font-weight:700;")
        else:
            self.setStyleSheet("background:transparent;border-radius:8px;"); self.i.setStyleSheet(f"color:{T3};"); self.t.setStyleSheet(f"color:{T2};")

class LiveChart(QWidget):
    def __init__(self):
        super().__init__(); self.d=[0.0]*60; self.setMinimumHeight(230); self.setStyleSheet(f"background:{BG4};border-radius:8px;")
    def push(self,v): self.d=(self.d+[float(v)])[-60:]; self.update()
    def paintEvent(self,e):
        p=QPainter(self); p.setRenderHint(QPainter.Antialiasing); w,h=self.width(),self.height(); pl,pr,pt,pb=44,12,14,34
        p.fillRect(self.rect(), QColor(BG4)); p.setPen(QPen(QColor("#252238"),1)); p.setFont(QFont("Segoe UI",7))
        for pct in [0,20,40,60,80,100]:
            y=pt+(1-pct/100)*(h-pt-pb); p.drawLine(pl,int(y),w-pr,int(y)); p.setPen(QColor(T3)); p.drawText(3,int(y+3),f"{pct}%"); p.setPen(QPen(QColor("#252238"),1))
        n=len(self.d); 
        if n<2: return
        xs=[pl+(1-i/(n-1))*(w-pl-pr) for i in range(n)]; ys=[pt+(1-v/100)*(h-pt-pb) for v in self.d]
        p.setPen(QPen(QColor(PUR2),2)); [p.drawLine(int(xs[i]),int(ys[i]),int(xs[i+1]),int(ys[i+1])) for i in range(n-1)]

class App(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle("SysOptimizer Pro"); self.resize(1280,820); self.setMinimumSize(1080,700)
        self._pages={}; self._navitems={}; self._chart_mode="CPU"; self._cpu=[0.0]*60; self._ram=[0.0]*60; self._gpu=[0.0]*60; self._gm=False
        c=QWidget(); self.setCentralWidget(c); root=QHBoxLayout(c); root.setContentsMargins(0,0,0,0); root.setSpacing(0)
        root.addWidget(self.sidebar()); root.addWidget(self.right(),1)
        self.live=QTimer(self); self.live.timeout.connect(self.tick_live); self.live.start(1500); QTimer.singleShot(300,self.boot)

    def sidebar(self):
        sb=QFrame(); sb.setFixedWidth(220); sb.setStyleSheet(f"background:{BG0};"); l=QVBoxLayout(sb); l.setContentsMargins(10,14,10,10)
        logo=QLabel("SYS  SysOptimizer\n      PRO EDITION"); logo.setStyleSheet(f"background:{PUR};color:white;padding:10px;border-radius:8px;font-weight:700;"); l.addWidget(logo)
        ai=QLabel("✦ AI Assistant"); ai.setStyleSheet(f"background:#180606;color:{RED};padding:8px;border:1px solid #5a2020;border-radius:8px;font-weight:700;"); l.addWidget(ai)
        for s in ["General","Main"]: t=QLabel(s); t.setStyleSheet(f"color:{T4};"); t.setFont(QFont("Segoe UI",8)); l.addWidget(t)
        for i,n,a in [("🏠","Home",True),("💾","Backups",False),("🔧","Fixes",False),("⚙","General",False),("💻","Hardware",False),("🗑","Debloat",False),("🌐","Network",False),("🎮","Game Mode",False),("⚡","Advanced",False),("🔲","BIOS",False)]:
            w=NavItem(i,n,a,lambda x=n:self.nav(x)); l.addWidget(w); self._navitems[n]=w
        q=QLabel("Quick Actions"); q.setStyleSheet(f"color:{T4};"); q.setFont(QFont("Segoe UI",8)); l.addWidget(q)
        for txt,fn in [("🧹 Clean Junk",self.fn_clean),("💨 Boost RAM",self.fn_ram),("🚀 Fix Startup",self.fn_startup),("🌐 Flush DNS",self.fn_dns),("🔒 Privacy Scan",self.fn_privacy),("💾 Disk Check",self.fn_disk)]:
            b=QPushButton(txt); b.clicked.connect(fn); b.setStyleSheet(f"QPushButton{{text-align:left;border:none;color:{T2};padding:6px;border-radius:6px;background:transparent;}}QPushButton:hover{{background:{BG3};color:{T1};}}"); l.addWidget(b)
        l.addStretch(1); u=QLabel("U  Admin User\n   Premium"); u.setStyleSheet(f"color:{T1};background:{BG0};padding:6px;"); l.addWidget(u); return sb

    def right(self):
        r=QFrame(); r.setStyleSheet(f"background:{BG1};"); l=QVBoxLayout(r); l.setContentsMargins(16,14,16,16)
        top=QHBoxLayout(); self.title=QLabel("Home - Overview"); self.title.setStyleSheet(f"color:{T1};font-weight:700;font-size:18px;")
        self.search=QLineEdit(); self.search.setPlaceholderText("Search settings..."); self.search.setFixedWidth(260); self.search.setStyleSheet(f"background:{BG2};color:{T1};border:1px solid {BORDER};border-radius:8px;padding:8px;")
        ob=QPushButton("Optimize Now"); ob.clicked.connect(self.do_fix); ob.setStyleSheet(f"background:{PUR};color:white;border:none;border-radius:8px;padding:10px 14px;font-weight:700;")
        top.addWidget(self.title); top.addStretch(1); top.addWidget(self.search); top.addWidget(ob); l.addLayout(top)
        self.stack=QVBoxLayout(); l.addLayout(self.stack,1)
        self.build_home(); self.build_hw(); self.build_net(); self.build_debloat(); self.build_gm();
        for k,t in [("Backups","Backups - System Restore Points"),("Fixes","Fixes - Apply System Patches"),("General","General - System Settings"),("Advanced","Advanced - Expert Tools"),("BIOS","BIOS - Firmware Optimization")]: self.placeholder(k,t)
        self.show_page("Home"); return r

    def page(self,name):
        host=QWidget(); host.setVisible(False); hl=QVBoxLayout(host); hl.setContentsMargins(0,0,0,0)
        sc=QScrollArea(); sc.setWidgetResizable(True); sc.setFrameShape(QFrame.NoFrame); sc.setStyleSheet(f"background:{BG1};border:none;")
        inner=QWidget(); inner.setStyleSheet(f"background:{BG1};"); il=QVBoxLayout(inner); il.setSpacing(10); sc.setWidget(inner); hl.addWidget(sc)
        self.stack.addWidget(host); self._pages[name]=host; return il
    def build_home(self):
        l=self.page("Home")
        h=QLabel("System Overview"); h.setStyleSheet(f"color:{T1};font-size:18px;font-weight:700;")
        s=QLabel("Performance dashboard and quick optimization tools"); s.setStyleSheet(f"color:{T3};")
        l.addWidget(h); l.addWidget(s)
        g=QGridLayout(); w=QWidget(); w.setLayout(g); l.addWidget(w)
        for c,t,d,fn in [(0,"💾 Backup & Restore","Create restore points before changes",self.do_backup),(1,"🎮 Game Mode","Disable background noise",self.toggle_gm),(2,"✦ AI Assistant","Smart recommendations",self.fn_privacy)]:
            x=card(); xl=QVBoxLayout(x); tt=QLabel(t); tt.setStyleSheet(f"color:{T1};font-weight:700;"); dd=QLabel(d); dd.setStyleSheet(f"color:{T2};"); dd.setWordWrap(True)
            b=QPushButton("Run"); b.clicked.connect(fn); b.setStyleSheet(f"background:{PUR};color:white;border:none;border-radius:6px;padding:8px;")
            xl.addWidget(tt); xl.addWidget(dd); xl.addStretch(1); xl.addWidget(b); g.addWidget(x,0,c)
        cp=card(); cl=QVBoxLayout(cp); th=QHBoxLayout(); th.addWidget(QLabel("Live Usage")); th.addStretch(1)
        self.ctabs={}
        for m in ["CPU","RAM","GPU"]:
            b=QPushButton(m); b.clicked.connect(lambda _,x=m:self.switch_chart(x)); self.ctabs[m]=b; th.addWidget(b)
        cl.addLayout(th); self.chart=LiveChart(); cl.addWidget(self.chart); l.addWidget(cp)
        mid=QHBoxLayout();
        q=card(); ql=QVBoxLayout(q); ql.addWidget(QLabel("Quickstart"));
        for t in ["✓ Create restore point","✓ Clean temporary files","○ Check startup items","○ Apply network tweaks"]: r=QLabel(t); r.setStyleSheet(f"color:{T2};"); ql.addWidget(r)
        log=card(); ll=QVBoxLayout(log); ll.addWidget(QLabel("Terminal")); self.log=QTextEdit(); self.log.setReadOnly(True); self.log.setStyleSheet(f"background:{BG4};color:{T1};border:1px solid {BORDER};border-radius:8px;"); ll.addWidget(self.log)
        mid.addWidget(q,1); mid.addWidget(log,1); mw=QWidget(); mw.setLayout(mid); l.addWidget(mw)
        act=card(); al=QVBoxLayout(act); al.addWidget(QLabel("Actions")); br=QHBoxLayout(); self.btn_scan=QPushButton("Deep Scan"); self.btn_fix=QPushButton("Fix All")
        self.btn_scan.clicked.connect(self.do_scan); self.btn_fix.clicked.connect(self.do_fix)
        for b in [self.btn_scan,self.btn_fix]: b.setStyleSheet(f"background:{PUR};color:white;border:none;border-radius:6px;padding:10px 14px;font-weight:700;"); br.addWidget(b)
        self.prog=QProgressBar(); self.prog.setRange(0,100); self.prog.setVisible(False); self.pl=QLabel(""); self.pl.setStyleSheet(f"color:{T3};"); self.pl.setVisible(False)
        rw=QWidget(); rw.setLayout(br); al.addWidget(rw); al.addWidget(self.prog); al.addWidget(self.pl); l.addWidget(act)
        news=QHBoxLayout(); nw=QWidget(); nw.setLayout(news)
        for t,b in [("Windows 11 Optimization Pack","New stability improvements for latest updates."),("Gaming Driver Advisory","Latency-focused profile available."),("Security Baseline","Privacy baseline updated.")]:
            c=card(); cl=QVBoxLayout(c); tt=QLabel(t); tt.setWordWrap(True); tt.setStyleSheet(f"color:{T1};font-weight:700;"); bb=QLabel(b); bb.setWordWrap(True); bb.setStyleSheet(f"color:{T2};"); cl.addWidget(tt); cl.addWidget(bb); news.addWidget(c,1)
        l.addWidget(nw); l.addWidget(QLabel("SysOptimizer Pro - EXM Layout"))

    def placeholder(self,key,title):
        l=self.page(key); h=QLabel(title); h.setStyleSheet(f"color:{T1};font-size:18px;font-weight:700;"); d=QLabel("This section keeps the original navigation layout."); d.setStyleSheet(f"color:{T3};"); l.addWidget(h); l.addWidget(d)

    def build_hw(self):
        l=self.page("Hardware"); l.addWidget(QLabel("💻 Hardware Information")); rows=[]
        try:
            if HAS_PSUTIL:
                cf=psutil.cpu_freq(); cc=psutil.cpu_count(); mem=psutil.virtual_memory(); disk=psutil.disk_usage("C:\\" if platform.system()=="Windows" else "/")
                rows=[("⚙ Processor",platform.processor()[:50] or "N/A"),("🔢 CPU Cores",f"{cc} logical cores"),("⚡ CPU Freq",f"{cf.current:.0f} MHz" if cf else "N/A"),("🧠 RAM Total",f"{mem.total//(1024**3)} GB"),("📊 RAM Used",f"{mem.percent:.1f}%"),("💾 Disk Total",f"{disk.total//(1024**3)} GB"),("📁 Disk Free",f"{disk.free//(1024**3)} GB"),("🖥 Platform",f"{platform.system()} {platform.release()}")]
        except Exception:
            rows=[("⚙ Processor",platform.processor()[:50] or "N/A"),("🖥 Platform",f"{platform.system()} {platform.release()}")]
        g=QGridLayout(); w=QWidget(); w.setLayout(g); l.addWidget(w)
        for i,(a,b) in enumerate(rows): c=card(); cl=QVBoxLayout(c); la=QLabel(a); la.setStyleSheet(f"color:{T3};"); lb=QLabel(b); lb.setStyleSheet(f"color:{T1};font-weight:700;"); lb.setWordWrap(True); cl.addWidget(la); cl.addWidget(lb); g.addWidget(c,i//2,i%2)

    def build_net(self):
        l=self.page("Network"); l.addWidget(QLabel("🌐 Network Settings"))
        for i,t,d,fn in [("🌐","Flush DNS Cache","Clear the DNS resolver cache",self.fn_dns),("📡","Reset Network Stack","Reset TCP/IP and Winsock",self.net_reset),("🔒","Disable IPv6","Disable IPv6 for faster routing",self.net_ipv6),("⚡","Enable QoS","Prioritize gaming traffic",self.net_qos)]:
            c=card(); r=QHBoxLayout(c); a=QLabel(i); a.setStyleSheet(f"color:{PUR2};"); txt=QVBoxLayout(); txt.addWidget(QLabel(t)); x=QLabel(d); x.setStyleSheet(f"color:{T3};"); txt.addWidget(x); b=QPushButton("Apply ->"); b.clicked.connect(fn); b.setStyleSheet(f"background:{PUR};color:white;border:none;border-radius:6px;padding:6px 10px;"); r.addWidget(a); r.addLayout(txt,1); r.addWidget(b); l.addWidget(c)

    def build_debloat(self):
        l=self.page("Debloat"); l.addWidget(QLabel("🗑 Debloat Windows")); g=QGridLayout(); w=QWidget(); w.setLayout(g); l.addWidget(w); self.bloat={}
        items=[("Cortana",True),("Xbox Game Bar",True),("OneDrive",False),("Teams",True),("Telemetry",True),("Edge Startup",False),("Tips & Tricks",True),("3D Objects",True)]
        for i,(n,dv) in enumerate(items):
            c=card(); cl=QVBoxLayout(c); r=QHBoxLayout(); nm=QLabel(n); nm.setStyleSheet(f"color:{T1};font-weight:700;"); t=QPushButton("REMOVE" if dv else "KEEP"); st={"on":dv}
            def paint(btn=t,s=st): btn.setStyleSheet(f"background:{'#180606' if s['on'] else '#071410'};color:{RED if s['on'] else GRN};border:none;border-radius:6px;padding:4px 8px;font-weight:700;")
            def flip(_,btn=t,s=st): s["on"]=not s["on"]; btn.setText("REMOVE" if s["on"] else "KEEP"); paint(btn,s)
            paint(); t.clicked.connect(flip); r.addWidget(nm); r.addStretch(1); r.addWidget(t); cl.addLayout(r); cl.addWidget(QLabel("Toggle removal state")); g.addWidget(c,i//2,i%2); self.bloat[n]=st
        ab=QPushButton("Apply Debloat Settings"); ab.clicked.connect(self.apply_debloat); ab.setStyleSheet(f"background:{PUR};color:white;border:none;border-radius:6px;padding:10px 14px;font-weight:700;"); l.addWidget(ab)

    def build_gm(self):
        l=self.page("Game Mode"); l.addWidget(QLabel("🎮 Game Mode"))
        for t in ["High Performance Mode","Disable Fullscreen Opt.","Suspend Notifications","Free RAM Before Game","Gaming Network Profile"]:
            c=card(); r=QHBoxLayout(c); r.addWidget(QLabel("🎮")); v=QVBoxLayout(); a=QLabel(t); a.setStyleSheet(f"color:{T1};font-weight:700;"); v.addWidget(a); v.addWidget(QLabel("Optimize this behavior")); tog=QPushButton("OFF"); tog.setCheckable(True); tog.toggled.connect(lambda on,b=tog:b.setText("ON" if on else "OFF")); tog.setStyleSheet(f"QPushButton{{background:{BG3};color:{T3};border:none;border-radius:6px;padding:6px 10px;}}QPushButton:checked{{background:{PUR};color:white;}}"); r.addLayout(v,1); r.addWidget(tog); l.addWidget(c)

    def nav(self,label):
        [i.set_active(k==label) for k,i in self._navitems.items()]
        t={"Home":"Home - Overview","Backups":"Backups - System Restore Points","Fixes":"Fixes - Apply System Patches","General":"General - System Settings","Hardware":"Hardware - Device Information","Debloat":"Debloat - Remove Bloatware","Network":"Network - Connection Tweaks","Game Mode":"Game Mode - Performance Profile","Advanced":"Advanced - Expert Tools","BIOS":"BIOS - Firmware Optimization"}
        self.title.setText(t.get(label,label)); self.show_page(label)

    def show_page(self,label):
        [p.setVisible(k==label) for k,p in self._pages.items()]

    def switch_chart(self,m):
        self._chart_mode=m
        for k,b in self.ctabs.items(): b.setStyleSheet(f"background:{PUR if k==m else BG3};color:{'white' if k==m else T3};border:none;border-radius:6px;padding:6px 10px;font-weight:700;")

    def tlog(self,msg,delay=0):
        fn=lambda:self.log.append(msg)
        QTimer.singleShot(delay,fn) if delay else fn()
    def boot(self):
        self.tlog("$ sysoptimizer --boot"); self.tlog("[OK] Engine initialized",300); self.tlog("[OK] Profile loaded: EXM",600); self.tlog("[OK] Ready",900)
    def do_backup(self): self.tlog("$ backup --create"); self.tlog("[OK] Restore point created ✓",700)
    def toggle_gm(self): self._gm=not self._gm; self.tlog(f"[OK] Game Mode: {'Enabled' if self._gm else 'Disabled'}")
    def fn_clean(self): self.tlog("$ clean --junk"); self.tlog("[..] Scanning temp files...",400); self.tlog("[OK] 847 MB freed ✓",1100)
    def fn_ram(self): self.tlog("$ boost --ram"); self.tlog("[..] Freeing standby memory...",400); self.tlog("[OK] 1.2 GB freed ✓",1100)
    def fn_startup(self): self.tlog("$ startup --fix"); self.tlog("[..] Checking startup entries...",400); self.tlog("[WARN] 3 slow entries found",900); self.tlog("[OK] Startup optimized - ~18s faster ✓",1500)
    def fn_dns(self):
        self.tlog("$ dns --flush")
        try: subprocess.Popen(["ipconfig","/flushdns"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception: pass
        self.tlog("[OK] DNS cache cleared ✓",700)
    def fn_privacy(self): self.tlog("$ privacy --scan"); self.tlog("[..] Scanning telemetry services...",400); self.tlog("[WARN] DiagTrack: RUNNING",900); self.tlog("[OK] Telemetry disabled - score: 94/100",1500)
    def fn_disk(self): self.tlog("$ disk --analyze"); self.tlog("[..] Analyzing C:\\ drive...",400); self.tlog("[OK] SSD detected - TRIM sent, health: 97%",1100)

    def run_progress(self,btn,running,orig,done=None):
        btn.setText(running); btn.setEnabled(False); self.prog.setVisible(True); self.pl.setVisible(True); self.prog.setValue(0); steps=["Analyzing...","Scanning...","Checking...","Reviewing...","Done!"]
        st={"i":0}
        def tick():
            i=st["i"]; self.prog.setValue(i); self.pl.setText(steps[min(i//20,4)])
            if i<100: st["i"]+=1; QTimer.singleShot(30,tick)
            else:
                def fin(): btn.setText(done or orig); btn.setEnabled(True); self.prog.setVisible(False); self.pl.setVisible(False); QTimer.singleShot(2500,lambda:btn.setText(orig)) if done else None
                QTimer.singleShot(400,fin)
        tick()
    def do_scan(self): self.run_progress(self.btn_scan,"Scanning...","Deep Scan"); self.tlog("$ scan --deep --all"); self.tlog("[..] Scanning registry...",300); self.tlog("[OK] 15 registry issues found",900); self.tlog("[..] Scanning filesystem...",1500); self.tlog("[OK] 10,104 KB junk found",2200); self.tlog("[OK] Scan complete - 261 issues",2900)
    def do_fix(self): self.run_progress(self.btn_fix,"Fixing...","Fix All",done="Fixed ✓"); self.tlog("$ fix --all --optimize"); self.tlog("[OK] Registry cleaned",400); self.tlog("[OK] 847 MB freed",900); self.tlog("[OK] All 261 issues resolved ✓",1400)
    def tick_live(self):
        t=time.time(); cpu=psutil.cpu_percent(interval=None) if HAS_PSUTIL else 20+30*abs(math.sin(t*0.3)); ram=psutil.virtual_memory().percent if HAS_PSUTIL else 45+15*abs(math.sin(t*0.2)); gpu=5+15*abs(math.sin(t*0.4))
        self._cpu=(self._cpu+[cpu])[-60:]; self._ram=(self._ram+[ram])[-60:]; self._gpu=(self._gpu+[gpu])[-60:]
        self.chart.push({"CPU":self._cpu,"RAM":self._ram,"GPU":self._gpu}[self._chart_mode][-1])
    def net_reset(self): self.tlog("$ netsh winsock reset"); self.tlog("[OK] Network stack reset - restart required",800)
    def net_ipv6(self): self.tlog("$ netsh int ipv6 set global disabled"); self.tlog("[OK] IPv6 disabled ✓",600)
    def net_qos(self): self.tlog("$ netsh qos set policy"); self.tlog("[OK] QoS policy applied ✓",600)
    def apply_debloat(self): self.nav("Home"); self.tlog("$ debloat --apply-selected"); self.tlog("[..] Applying debloat settings...",300); self.tlog("[OK] Debloat complete - restart recommended ✓",1200)

if __name__=="__main__":
    app=QApplication(sys.argv); w=App(); w.show(); sys.exit(app.exec())
